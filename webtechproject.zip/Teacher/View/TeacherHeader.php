<tr>
         <td colspan="2">
          <table width="100%">
              <tr>
              <img src="../Resources/school_logo.png" alt="School Logo" style="width: 350px; height: 110px;">

                <td align = "right">
                  <!--  <a href="../Controller/Logout.php">Logout</a> -->
                </td>
              </tr>
          </table>
          </td>
      </tr>