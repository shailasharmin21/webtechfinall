<?php

header("location:../Views/editProfile.php");

?>