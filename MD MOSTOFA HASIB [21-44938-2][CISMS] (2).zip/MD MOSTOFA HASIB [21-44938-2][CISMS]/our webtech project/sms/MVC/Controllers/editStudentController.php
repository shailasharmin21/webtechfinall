<?php

header("location:../Views/editStudent.php");

?>