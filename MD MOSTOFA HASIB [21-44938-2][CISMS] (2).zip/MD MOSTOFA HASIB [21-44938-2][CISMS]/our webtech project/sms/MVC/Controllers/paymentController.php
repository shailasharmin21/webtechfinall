<?php

header("location:../Views/payment.php");

?>