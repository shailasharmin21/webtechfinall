<?php

header("location:../Views/viewStudent.php");

?>