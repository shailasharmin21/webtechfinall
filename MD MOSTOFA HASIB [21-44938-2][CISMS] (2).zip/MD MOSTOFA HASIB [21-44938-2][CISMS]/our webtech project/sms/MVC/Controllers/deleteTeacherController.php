<?php

header("location:../Views/viewTeacher.php");

?>