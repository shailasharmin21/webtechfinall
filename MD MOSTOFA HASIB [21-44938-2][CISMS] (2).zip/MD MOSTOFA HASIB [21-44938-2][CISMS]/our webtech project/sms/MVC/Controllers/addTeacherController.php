<?php

header("location:../Views/addTeacher.php");

?>