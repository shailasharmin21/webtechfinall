<?php

require_once('../Models/database.php');
require_once('../Models/userModel.php');

$notices = getAllNotice();

?>
