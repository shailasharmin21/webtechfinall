<?php

header("location:../Views/editTeacher.php");

?>