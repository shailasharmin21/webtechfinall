<?php

header("location:../Views/noticePost.php");

?>