<?php

header("location:../Views/registration.php");

?>