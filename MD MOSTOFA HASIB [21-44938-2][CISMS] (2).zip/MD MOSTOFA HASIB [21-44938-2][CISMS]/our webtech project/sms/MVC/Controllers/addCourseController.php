<?php

header("location:../Views/addCourse.php");

?>