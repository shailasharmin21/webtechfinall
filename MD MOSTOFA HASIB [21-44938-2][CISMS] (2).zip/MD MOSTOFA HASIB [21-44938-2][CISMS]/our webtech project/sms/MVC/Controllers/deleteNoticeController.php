<?php

header("location:../Views/viewNotice.php");

?>