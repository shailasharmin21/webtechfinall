<?php

header("location:../Views/editNotice.php");

?>