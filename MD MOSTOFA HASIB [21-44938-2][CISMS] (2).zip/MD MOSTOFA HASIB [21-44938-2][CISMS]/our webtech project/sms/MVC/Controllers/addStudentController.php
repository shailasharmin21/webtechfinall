<?php

header("location:../Views/addStudent.php");

?>