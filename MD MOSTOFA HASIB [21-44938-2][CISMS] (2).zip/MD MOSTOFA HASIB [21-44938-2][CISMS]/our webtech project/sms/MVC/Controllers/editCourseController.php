<?php

header("location:../Views/editCourse.php");

?>