<tr>
        <td align="center" colspan="2" ></td>
      </tr>

    </table>

  </body>
</html><!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title></title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f2f2f2;
    }

    .footer {
      background-color: #fff;
      padding: 10px;
      text-align: center;
      border-top: 1px solid #ccc;
    }

    .footer-text {
      color: #555;
      font-size: 14px;
    }
  </style>
</head>
<body>
  <div class="footer">
    <p class="footer-text">Creative International School Mangement System</p>
  </div>
</body>
</html>
